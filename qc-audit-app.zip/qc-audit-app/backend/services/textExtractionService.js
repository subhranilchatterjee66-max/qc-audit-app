const fs = require('fs');
const pdfParse = require('pdf-parse');
const mammoth = require('mammoth');

async function extractText(file) {
  const { path, mimetype, originalname } = file;

  if (mimetype === 'application/pdf' || originalname.toLowerCase().endsWith('.pdf')) {
    const dataBuffer = fs.readFileSync(path);
    const data = await pdfParse(dataBuffer);
    return cleanText(data.text);
  }

  if (
    mimetype === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ||
    originalname.toLowerCase().endsWith('.docx')
  ) {
    const result = await mammoth.extractRawText({ path });
    return cleanText(result.value);
  }

  if (originalname.toLowerCase().endsWith('.txt')) {
    return cleanText(fs.readFileSync(path, 'utf8'));
  }

  throw new Error(`Unsupported file type: ${originalname}`);
}

function cleanText(text) {
  return String(text || '')
    .replace(/\r/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .replace(/[ \t]{2,}/g, ' ')
    .trim();
}

module.exports = { extractText };
