import re

RUBRIC_SIGNALS = [
    "learning outcome", "criterion", "criteria", "marks", "weight", "%", "excellent",
    "distinction", "merit", "pass", "fail", "critical", "analysis", "application"
]

def extract_rubric_signals(rubric: str) -> dict:
    lower = (rubric or "").lower()
    signals = [s for s in RUBRIC_SIGNALS if s in lower]
    percentages = re.findall(r"\b\d{1,3}\s*%", rubric or "")
    possible_criteria = []
    for line in (rubric or "").splitlines():
        line_clean = line.strip()
        if len(line_clean) > 5 and any(sig in line_clean.lower() for sig in ["analysis", "knowledge", "structure", "reference", "application", "critical"]):
            possible_criteria.append(line_clean[:180])
    return {
        "signals_found": signals,
        "percentage_weights_found": percentages,
        "possible_criteria": possible_criteria[:20]
    }
