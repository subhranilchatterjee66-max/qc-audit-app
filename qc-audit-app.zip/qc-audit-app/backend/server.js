require('dotenv').config();
const express = require('express');
const cors = require('cors');
const analyseRoutes = require('./routes/analyseRoutes');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json({ limit: '10mb' }));

app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'qc-audit-backend' });
});

app.use('/api', analyseRoutes);

app.listen(PORT, () => {
  console.log(`Backend running on port ${PORT}`);
});
