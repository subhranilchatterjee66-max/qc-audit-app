const fs = require('fs');
const { extractText } = require('../services/textExtractionService');
const { runQcEngine } = require('../services/qcEngineService');

async function analyseAssignment(req, res) {
  const uploadedPaths = [];

  try {
    if (!req.files?.brief || !req.files?.rubric || !req.files?.submission) {
      return res.status(400).json({ error: 'Brief, rubric, and submission files are required.' });
    }

    const briefFile = req.files.brief[0];
    const rubricFile = req.files.rubric[0];
    const submissionFile = req.files.submission[0];
    uploadedPaths.push(briefFile.path, rubricFile.path, submissionFile.path);

    const briefText = await extractText(briefFile);
    const rubricText = await extractText(rubricFile);
    const submissionText = await extractText(submissionFile);

    const strictness = req.body.strictness || 'Professor Strict';

    const result = await runQcEngine({
      brief: briefText,
      rubric: rubricText,
      submission: submissionText,
      strictness
    });

    return res.json(result);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'QC analysis failed.' });
  } finally {
    uploadedPaths.forEach((filePath) => {
      if (filePath && fs.existsSync(filePath)) fs.unlinkSync(filePath);
    });
  }
}

module.exports = { analyseAssignment };
