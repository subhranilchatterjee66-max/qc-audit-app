import re

HARVARD_PATTERN = re.compile(r"\([A-Z][A-Za-z'\-]+(?:\s+et\s+al\.)?,\s*20\d{2}\)")
APA_PATTERN = re.compile(r"\([A-Z][A-Za-z'\-]+(?:\s+et\s+al\.)?,\s*20\d{2}\)")
REFERENCE_HINTS = ["references", "bibliography", "reference list"]

def citation_summary(text: str) -> dict:
    citations = HARVARD_PATTERN.findall(text or "")
    lower = (text or "").lower()
    has_reference_list = any(hint in lower for hint in REFERENCE_HINTS)
    paragraphs = [p.strip() for p in re.split(r"\n\s*\n", text or "") if p.strip()]
    uncited_paragraphs = [p[:140] for p in paragraphs if not HARVARD_PATTERN.search(p)]

    return {
        "in_text_citation_count": len(citations),
        "unique_citation_count": len(set(citations)),
        "has_reference_list": has_reference_list,
        "uncited_paragraph_count": len(uncited_paragraphs),
        "sample_uncited_paragraphs": uncited_paragraphs[:5]
    }
