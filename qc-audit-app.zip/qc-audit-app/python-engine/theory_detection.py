THEORY_KEYWORDS = [
    "theory", "model", "framework", "stakeholder theory", "porter", "pestle", "swot",
    "resource based view", "institutional theory", "diffusion", "maslow", "kolb",
    "gibbs", "carroll", "balanced scorecard", "ansoff", "hofstede", "trompenaars"
]

APPLICATION_TERMS = [
    "applied", "in the case", "this shows", "this suggests", "therefore", "however",
    "although", "compared", "evaluates", "critically", "limitation", "implication"
]

def theory_summary(text: str) -> dict:
    lower = (text or "").lower()
    theories_found = sorted({kw for kw in THEORY_KEYWORDS if kw in lower})
    application_markers = sorted({kw for kw in APPLICATION_TERMS if kw in lower})
    depth = "Weak"
    if len(theories_found) >= 4 and len(application_markers) >= 6:
        depth = "Strong"
    elif len(theories_found) >= 2 and len(application_markers) >= 3:
        depth = "Moderate"
    return {
        "theories_found": theories_found,
        "application_markers": application_markers,
        "depth_estimate": depth
    }
