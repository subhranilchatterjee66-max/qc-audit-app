const express = require('express');
const multer = require('multer');
const { analyseAssignment } = require('../controllers/analyseController');

const router = express.Router();
const upload = multer({ dest: 'uploads/' });

router.post(
  '/analyse',
  upload.fields([
    { name: 'brief', maxCount: 1 },
    { name: 'rubric', maxCount: 1 },
    { name: 'submission', maxCount: 1 }
  ]),
  analyseAssignment
);

module.exports = router;
