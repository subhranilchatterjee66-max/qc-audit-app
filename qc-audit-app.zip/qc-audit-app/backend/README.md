# Backend

## Run

```bash
npm install
cp .env.example .env
npm run dev
```

API endpoint:

```http
POST /api/analyse
```

Multipart fields:

- brief
- rubric
- submission
- strictness
