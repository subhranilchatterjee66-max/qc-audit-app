import os
import re
from dotenv import load_dotenv
from openai import OpenAI
from citation_checker import citation_summary
from theory_detection import theory_summary
from rubric_analyser import extract_rubric_signals
from grammar_checker import writing_quality_summary

load_dotenv()

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
MODEL = os.getenv("OPENAI_MODEL", "gpt-4.1")

SYSTEM_PROMPT = """
You are a strict postgraduate-level academic quality controller.
Your job is not to rewrite the assignment.
Your job is to audit the assignment against the brief and marking rubric.
Be honest, strict, evidence-based, and professor-level.
HD means near perfect, not merely good.
Return a detailed structured QC report using the exact 12-section format requested.
"""

USER_PROMPT_TEMPLATE = """
STRICTNESS LEVEL: {strictness}

You must evaluate whether the student submission can realistically receive 80+.

Use this structure exactly:

# 1. REQUIREMENT MATCH CHECK
Use ✅ Covered, ⚠️ Partially Covered, or ❌ Missing.

# 2. RUBRIC-BASED EVALUATION
For each rubric criterion include:
- Expected for HD:
- What student has done:
- Gap:
- Verdict: HD / Distinction / Merit / Pass / Fail

# 3. CRITICAL THINKING & ARGUMENT QUALITY
- Level: High / Medium / Low
- Issue examples

# 4. USE OF THEORY, MODELS & CONCEPTS
- Depth: Strong / Moderate / Weak
- Missing theories if relevant

# 5. EVIDENCE, DATA & REAL-WORLD SUPPORT
- Strength: Strong / Moderate / Weak
- Issues with sources, data, weak evidence, outdated claims, or unsupported statements

# 6. ALIGNMENT & FLOW
- Alignment: Strong / Moderate / Weak
- Specific breakdown issues

# 7. REFERENCING QUALITY
- Accuracy: High / Medium / Low
- Suspicious citations or formatting issues

# 8. ACADEMIC WRITING QUALITY
- Level: HD / Good / Needs Improvement
- Key issues

# 9. STRUCTURE & FORMATTING
- Quality: Professional / Average / Poor

# 10. HD GAP ANALYSIS
List exactly what is stopping this from getting 80+.
For each issue include:
1. Issue:
2. Why it affects grade:
3. What needs to be fixed:

# 11. FINAL GRADE ESTIMATION
- Estimated Score: __ / 100
- Band: HD / Distinction / Merit / Pass / Fail

# 12. FINAL VERDICT
Choose only one:
✅ HD READY
⚠️ CLOSE TO HD
❌ NOT HD

Important rules:
- Do not rewrite the assignment.
- Do not flatter.
- Do not give generic advice.
- Justify every judgement.
- If the rubric is vague, state this clearly.

HEURISTIC CHECKS FROM SYSTEM:
Citation summary:
{citation_summary}

Theory summary:
{theory_summary}

Rubric signal summary:
{rubric_summary}

Writing quality summary:
{writing_summary}

ASSIGNMENT BRIEF:
{brief}

MARKING RUBRIC:
{rubric}

STUDENT SUBMISSION:
{submission}
"""

def truncate_text(text: str, max_chars: int = 45000) -> str:
    text = text or ""
    if len(text) <= max_chars:
        return text
    start = text[: int(max_chars * 0.65)]
    end = text[-int(max_chars * 0.35):]
    return start + "\n\n[TEXT TRUNCATED FOR MODEL CONTEXT]\n\n" + end


def parse_score(report: str) -> int:
    patterns = [
        r"Estimated Score:\s*(\d{1,3})\s*/\s*100",
        r"Estimated score\s*[:\-]\s*(\d{1,3})",
        r"Score\s*[:\-]\s*(\d{1,3})\s*/\s*100"
    ]
    for pattern in patterns:
        match = re.search(pattern, report or "", flags=re.I)
        if match:
            value = int(match.group(1))
            return max(0, min(100, value))
    return 0


def band_from_score(score: int) -> str:
    if score >= 80:
        return "HD"
    if score >= 70:
        return "Distinction"
    if score >= 60:
        return "Merit"
    if score >= 50:
        return "Pass"
    return "Fail"


def verdict_from_score(score: int) -> str:
    if score >= 80:
        return "HD READY"
    if score >= 70:
        return "CLOSE TO HD"
    return "NOT HD"


def generate_qc_report(brief: str, rubric: str, submission: str, strictness: str = "Professor Strict") -> dict:
    brief = truncate_text(brief, 22000)
    rubric = truncate_text(rubric, 22000)
    submission = truncate_text(submission, 65000)

    heuristics = {
        "citation_summary": citation_summary(submission),
        "theory_summary": theory_summary(submission),
        "rubric_summary": extract_rubric_signals(rubric),
        "writing_summary": writing_quality_summary(submission)
    }

    prompt = USER_PROMPT_TEMPLATE.format(
        strictness=strictness,
        citation_summary=heuristics["citation_summary"],
        theory_summary=heuristics["theory_summary"],
        rubric_summary=heuristics["rubric_summary"],
        writing_summary=heuristics["writing_summary"],
        brief=brief,
        rubric=rubric,
        submission=submission
    )

    completion = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": prompt}
        ],
        temperature=0.15
    )

    report = completion.choices[0].message.content
    score = parse_score(report)

    return {
        "estimated_score": score,
        "final_band": band_from_score(score),
        "final_verdict": verdict_from_score(score),
        "heuristics": heuristics,
        "report": report
    }
