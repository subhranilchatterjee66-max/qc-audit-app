import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Upload, FileText, ClipboardCheck, BarChart3, AlertTriangle, CheckCircle2, XCircle, Sparkles, Loader2 } from 'lucide-react';
import { analyseAssignment } from './lib/api';

const auditSections = [
  'Requirement Match Check',
  'Rubric-Based Evaluation',
  'Critical Thinking & Argument Quality',
  'Use of Theory, Models & Concepts',
  'Evidence, Data & Real-World Support',
  'Alignment & Flow',
  'Referencing Quality',
  'Academic Writing Quality',
  'Structure & Formatting',
  'HD Gap Analysis',
  'Final Grade Estimation',
  'Final Verdict'
];

function estimateBand(score) {
  if (score >= 80) return { band: 'HD', verdict: 'HD READY', tone: 'text-green-700', icon: CheckCircle2 };
  if (score >= 70) return { band: 'Distinction', verdict: 'CLOSE TO HD', tone: 'text-yellow-700', icon: AlertTriangle };
  if (score >= 60) return { band: 'Merit', verdict: 'NOT HD', tone: 'text-orange-700', icon: AlertTriangle };
  if (score >= 50) return { band: 'Pass', verdict: 'NOT HD', tone: 'text-red-700', icon: XCircle };
  return { band: 'Fail', verdict: 'NOT HD', tone: 'text-red-800', icon: XCircle };
}

export default function App() {
  const [brief, setBrief] = useState(null);
  const [rubric, setRubric] = useState(null);
  const [submission, setSubmission] = useState(null);
  const [strictness, setStrictness] = useState('Professor Strict');
  const [loading, setLoading] = useState(false);
  const [audit, setAudit] = useState(null);
  const [error, setError] = useState('');

  const score = audit?.estimated_score ?? 0;
  const band = estimateBand(score);
  const VerdictIcon = band.icon;

  async function handleGenerateAudit() {
    setError('');

    if (!brief || !rubric || !submission) {
      setError('Please upload the assignment brief, marking rubric, and student submission.');
      return;
    }

    setLoading(true);

    try {
      const result = await analyseAssignment({ brief, rubric, submission, strictness });
      setAudit(result);
    } catch (err) {
      setError(err.response?.data?.error || 'QC analysis failed. Check backend and Python engine are running.');
    } finally {
      setLoading(false);
    }
  }

  function downloadReport() {
    if (!audit?.report) return;
    const blob = new Blob([audit.report], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'qc-audit-report.txt';
    link.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="min-h-screen bg-slate-50 p-6 text-slate-900">
      <div className="mx-auto max-w-7xl space-y-6">
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="grid gap-6 lg:grid-cols-[1.15fr_0.85fr]">
          <div className="rounded-2xl bg-white p-8 shadow-sm">
            <div className="mb-6 flex items-center gap-3">
              <div className="rounded-2xl bg-slate-900 p-3 text-white"><ClipboardCheck size={26} /></div>
              <div>
                <h1 className="text-3xl font-bold tracking-tight">Academic QC Audit Web App</h1>
                <p className="mt-1 text-slate-600">Strict postgraduate assignment checker for HD readiness, rubric alignment, and grade risk.</p>
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-3">
              <UploadBox title="Assignment Brief" file={brief} setFile={setBrief} />
              <UploadBox title="Marking Rubric" file={rubric} setFile={setRubric} />
              <UploadBox title="Student Submission" file={submission} setFile={setSubmission} />
            </div>

            <div className="mt-6 rounded-2xl border bg-white p-5">
              <label className="text-sm font-semibold text-slate-700">Strictness Level</label>
              <select value={strictness} onChange={(e) => setStrictness(e.target.value)} className="mt-2 w-full rounded-xl border p-3">
                <option>Balanced Academic</option>
                <option>Professor Strict</option>
                <option>HD Gatekeeper</option>
                <option>Dissertation Examiner</option>
              </select>
              <p className="mt-2 text-sm text-slate-500">HD Gatekeeper treats 80+ as near-perfect and highlights every major grade risk.</p>
            </div>

            {error && <div className="mt-4 rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-700">{error}</div>}

            <button onClick={handleGenerateAudit} disabled={loading} className="mt-6 flex w-full items-center justify-center rounded-2xl bg-slate-900 px-4 py-4 text-base font-semibold text-white disabled:opacity-60">
              {loading ? <Loader2 className="mr-2 animate-spin" size={18} /> : <Sparkles className="mr-2" size={18} />}
              {loading ? 'Running QC Audit...' : 'Generate Strict QC Audit'}
            </button>
          </div>

          <div className="rounded-2xl bg-white p-8 shadow-sm">
            <div className="flex items-center gap-3">
              <BarChart3 className="text-slate-700" size={26} />
              <h2 className="text-2xl font-bold">Grade Snapshot</h2>
            </div>
            <div className="mt-6 rounded-2xl bg-slate-50 p-6 text-center shadow-sm">
              <div className="text-6xl font-extrabold">{audit ? score : '--'}</div>
              <div className="mt-1 text-sm text-slate-500">Estimated Score / 100</div>
              <div className={`mt-4 flex items-center justify-center gap-2 text-xl font-bold ${audit ? band.tone : 'text-slate-500'}`}>
                {audit ? <VerdictIcon size={24} /> : <AlertTriangle size={24} />} {audit ? band.verdict : 'NO AUDIT YET'}
              </div>
              <p className="mt-2 text-slate-600">Band: {audit ? band.band : 'Pending'}</p>
            </div>
          </div>
        </motion.div>

        <div className="grid gap-6 lg:grid-cols-[0.8fr_1.2fr]">
          <div className="rounded-2xl bg-white p-6 shadow-sm">
            <h2 className="mb-4 text-xl font-bold">QC Output Structure</h2>
            <div className="space-y-2">
              {auditSections.map((section, index) => (
                <div key={section} className="flex items-center gap-3 rounded-xl bg-slate-50 p-3 text-sm shadow-sm">
                  <span className="flex h-7 w-7 items-center justify-center rounded-full bg-slate-900 text-xs font-bold text-white">{index + 1}</span>
                  {section}
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-2xl bg-white p-6 shadow-sm">
            <div className="mb-4 flex items-center justify-between gap-3">
              <h2 className="text-xl font-bold">Generated Audit Report</h2>
              <button onClick={downloadReport} disabled={!audit?.report} className="rounded-xl border px-4 py-2 text-sm font-semibold disabled:opacity-50">Export TXT</button>
            </div>

            {!audit ? (
              <div className="flex min-h-[420px] items-center justify-center rounded-2xl border border-dashed bg-slate-50 p-8 text-center text-slate-500">
                Upload the brief, rubric, and submission, then generate the strict QC audit.
              </div>
            ) : (
              <pre className="max-h-[720px] overflow-auto whitespace-pre-wrap rounded-2xl bg-slate-950 p-5 text-sm leading-6 text-slate-100">{audit.report}</pre>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function UploadBox({ title, file, setFile }) {
  return (
    <label className="cursor-pointer rounded-2xl border border-dashed bg-white p-5 text-center shadow-sm transition hover:bg-slate-50">
      <FileText className="mx-auto mb-3 text-slate-600" size={30} />
      <div className="font-semibold">{title}</div>
      <div className="mt-1 truncate text-xs text-slate-500">{file ? file.name : 'Upload DOCX, PDF, or TXT'}</div>
      <input type="file" className="hidden" accept=".pdf,.doc,.docx,.txt" onChange={(e) => setFile(e.target.files?.[0] || null)} />
    </label>
  );
}
