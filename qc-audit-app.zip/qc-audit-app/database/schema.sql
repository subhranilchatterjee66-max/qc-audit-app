CREATE TABLE IF NOT EXISTS audits (
    id SERIAL PRIMARY KEY,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    student_name TEXT,
    module_name TEXT,
    assignment_title TEXT,
    estimated_score INTEGER,
    final_band TEXT,
    final_verdict TEXT,
    report TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS uploaded_files (
    id SERIAL PRIMARY KEY,
    audit_id INTEGER REFERENCES audits(id) ON DELETE CASCADE,
    file_type TEXT NOT NULL,
    original_name TEXT NOT NULL,
    extracted_text TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
