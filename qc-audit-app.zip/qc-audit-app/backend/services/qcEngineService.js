const axios = require('axios');

const PYTHON_ENGINE_URL = process.env.PYTHON_ENGINE_URL || 'http://localhost:8000';

async function runQcEngine(payload) {
  const response = await axios.post(`${PYTHON_ENGINE_URL}/qc`, payload, {
    timeout: 180000
  });

  return response.data;
}

module.exports = { runQcEngine };
