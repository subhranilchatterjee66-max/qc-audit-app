from fastapi import FastAPI
from pydantic import BaseModel, Field
from qc_engine import generate_qc_report

app = FastAPI(title="Academic QC Engine", version="1.0.0")

class QCRequest(BaseModel):
    brief: str = Field(..., min_length=10)
    rubric: str = Field(..., min_length=10)
    submission: str = Field(..., min_length=10)
    strictness: str = "Professor Strict"

@app.get('/health')
def health():
    return {"status": "ok", "service": "academic-qc-engine"}

@app.post('/qc')
def qc(request: QCRequest):
    return generate_qc_report(
        brief=request.brief,
        rubric=request.rubric,
        submission=request.submission,
        strictness=request.strictness
    )
