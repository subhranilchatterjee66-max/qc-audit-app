import re

def writing_quality_summary(text: str) -> dict:
    sentences = re.split(r"(?<=[.!?])\s+", text or "")
    words = re.findall(r"\b\w+\b", text or "")
    long_sentences = [s for s in sentences if len(re.findall(r"\b\w+\b", s)) > 35]
    passive_like = re.findall(r"\b(is|are|was|were|be|been|being)\s+\w+ed\b", text or "", flags=re.I)

    return {
        "word_count": len(words),
        "sentence_count": len([s for s in sentences if s.strip()]),
        "long_sentence_count": len(long_sentences),
        "passive_like_count": len(passive_like),
        "sample_long_sentences": [s[:180] for s in long_sentences[:5]]
    }
