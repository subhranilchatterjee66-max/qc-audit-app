function getBand(score) {
  if (score >= 80) return 'HD';
  if (score >= 70) return 'Distinction';
  if (score >= 60) return 'Merit';
  if (score >= 50) return 'Pass';
  return 'Fail';
}

module.exports = { getBand };
